# Uber Data Analytics 
This project aims to analyze Uber data utilizing the dataset through the creation of a dashboard and querying to extract insights.

# Technology Used
- Python
- SQL
- Google Cloud Platform
  - Cloud Storage
  - BigQuery
  - VM Instance
  - API & Services
- Mage
- Looker Studio
- Jupyter NoteBook - IDE

  
# Architecture Diagram

![Architecure Diagram](https://github.com/nikitadevendran/uber-data-analytics/blob/main/Architecture%20Diagram.png)


